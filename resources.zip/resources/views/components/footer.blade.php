<footer class="footer">

    <div class="row footer-header">
        <div class="wrapper">
        <h3>CONTACTO</h3>
        <h3>SITEMAP</h3>
        <h3>INFORMACIÓN</h3>
        </div>
    </div>
    <div class="row footer-content">
        <div class="wrapper">
            <div class="col contact">
                <h1>Gastro Innova</h1>
                <h2>Km 1Via Siberia Funza Bod 28 A Zn Franca</h2> 
               <div class="phone">Teléfono: (57) 1 8759282</div>
                <div class="email">E-mail: info@gastroinnova-co.com</div>
                <div class="website">Website: gastroinnova-co.com</div>
            </div>
            <div class="col links">
                <a>Inicio</a>
                <a>Clientes</a>
                <a>Noticias</a>
                <a>Contacto</a>
            </div>
            <div class="col info">
                
                <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
            </div>
        </div>
    </div>
     <div class="row social">

        <ul class="social-icons">
            <li class="icon facebook"><i class="fab fa-facebook-f"></i>

</li>
            <li class="icon instagram"><i class="fab fa-instagram"></i>

</li>
            <li class="icon twitter"><i class="fab fa-twitter"></i>

</li>
        <li class="icon twitter"><i class="fas fa-envelope"></i>

</i>

</li>
        </ul>

        <div class="terms"><a href="/terms">TERMINOS DE USO</a></div>
        <div class="terms"><a href="/policies">POLITÍCAS DE DATOS</a></div>

    </div>
    <div class="row copyright">

        © @php echo date("Y"); @endphp Gastroinnova. Todos los derechos reservados. Desarrollado por www.mundanoburo.com

    </div>


</footer>
