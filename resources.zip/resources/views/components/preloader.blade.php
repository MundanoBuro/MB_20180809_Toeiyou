<div class="wrapper">


    <img src="ico/loader.gif">


</div>

<script>

</script>