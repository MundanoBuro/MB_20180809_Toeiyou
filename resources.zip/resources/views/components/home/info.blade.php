         <div class=" card deliz" >
                        <div class="cover" style="background-image:url('images/info/card-deliz.png')"></div>
                        <div class="banner">DELIZ</div>
                    </div>
                    <div class=" card pitadora" >
                        <div class="cover" style="background-image:url('images/info/card-pitadora.png')"></div>
                        <div class="banner">READY MEALS</div>
                    </div>
                    <div class=" card startups" >
                        <div class="cover" style="background-image:url('images/info/card-startups.jpeg')"></div>
                        <div class="banner">START-UPS</div>
                    </div>